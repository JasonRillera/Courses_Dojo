from django.db import models

# Create your models here.
class CourseManager(models.Manager):
    def create_validator(self, reqPOST):
        errors = {}
        if len(reqPOST['course_name']) < 6:
            errors['name'] = "Name should be atleast 5 characters!"
        if len(reqPOST['description']) < 16:
            errors['desc'] = "Description should be atleast 15 characters!"
        return errors

class Course(models.Model):
    name = models.TextField()
    description = models.TextField()
    created_at = models.DateField(auto_now_add=True)
    updated_at =  models.DateField(auto_now=True)
    objects = CourseManager()